//Robert Bajan 10/10/21
const { response } = require("express")
const express = require("express")
const validator = require("validator")
const bodyParser = require("body-parser")
const mongoose = require("mongoose")
const bcrypt = require("bcrypt")
const passport = require('passport')
const GoogleStrategy = require('passport-google-oauth20').Strategy
const config = require('./config')
const RememberMeStrategy = require('passport-remember-me').Strategy
const Stripe = require('stripe')(config.SecretKey)
const Paypal = require('paypal-rest-sdk')
const app = express()

app.use(express.static("Public"))
app.use(bodyParser.urlencoded({extended:true}))
app.use(passport.initialize())

passport.serializeUser(function(user, done) {
    done(null, user)
})

passport.deserializeUser(function(user, done) {
    done(null, user)
})

passport.use(new GoogleStrategy({       //Collects all credentials in order to be able to access the google sign in
    clientID: config.clientId,
    clientSecret: config.secret,
    callbackURL: config.callback,
    passReqToCallback: true
},function(request,accessToken,refreshToken,profile, done){
    return done(null,profile)
}))

//Database Schema
//
//
//

const saltRounds = 10;

mongoose.connect("mongodb+srv://admin:admin@iservice.0pw77.mongodb.net/iService?retryWrites=true&w=majority", {useNewUrlParser: true})      //Sets up the local database
    
    const userSchema = new mongoose.Schema(             //Sets up the MongoDB Schema
        {
            first:{
                type: String,
                required: true
            },
            last:{
                type: String,
                required: true
            },
            email: {
                type: String,
                required: true,
                lowercase: true,
                index: { unique: true },
                validate: [validator.isEmail, "The email provided is not valid"],
                validate(value) {
                    if (!validator.isEmail(value)){
                        throw new Error("The email provided is not valid")
                    }
                }
            },
            residence:{
                type: String,
                required: true
            },
            password:{
                type: String,
                required: true,
                minlength: 8
            },
            conpassword:{
                type: String,
                required: true,
                minlength: 8
            },
            address:{
                type: String,
                required: true
            },
            city:{
                type: String,
                required: true
            },
            state:{
                type: String,
                required: true
            },
            postal:{
                type: Number,
                required: false,
                minlength: 4,
                maxlength: 4
            },
            mobile:{
                type: Number,
                required:false
            }
        }
    )

    const User = mongoose.model('Users', userSchema)         //Turns the schema into a usable model

//Get Requests
//
//
//

app.get('/', (req, res)=> {             //Retrieves the html file and presents in on the local server via the web browser
    res.sendFile(__dirname + "/login.html")
})

app.get('/signup', (req, res)=> {             //Retrieves the html file and presents in on the local server via the web browser
    res.sendFile(__dirname + "/signup.html")
})

app.get('/google', passport.authenticate('google', {scope:['profile', 'email']}))       //Retrieves the Google signin page and presents it top the user
app.get('/google/callback', passport.authenticate('google', {failureRedirect: '/failed'}),      //Acknowledges the authentication and calls back to the payment page
    function(req, res) {
        res.redirect("/payment")
    }
)

app.get('/payment', (req, res) =>{      //Retrieves the html file and presents in on the local server via the web browser
    res.sendFile(__dirname + "/payment.html", {
        key: config.PublishableKey
    })
})

//Post Requests
//
//
//

app.post('/payment', function(req, res){        //Retrieves the post from the payment page and redirects the user to the card purchase screen
    Stripe.customers.create({ 
        email: req.body.stripeEmail, 
        source: req.body.stripeToken
    }) 
    .then((customer) => { 

        return Stripe.charges.create({ 
            amount: 199,
            description: 'iService Subscription', 
            currency: 'AUD', 
            customer: customer.id 
        }); 
    }) 
    .then((charge) => { 
        res.send("Payment Successful")
    }) 
    .catch((err) => { 
        res.send(err)
    }); 
})

Paypal.configure({      //configues the credentials in order to be able to access paypal
    'mode': config.mode,
    'client_id': config.paypalClientId,
    'client_secret': config.paypalSecret
});

app.post('/paypal', (req, res) => {     //Retrieves the post from the paypal page and redirects the user to the paypal purchase page
    const create_payment_json = {
        "intent": "sale",
        "payer": {
            "payment_method": "paypal"
        },
        "redirect_urls": {
            "return_url": "https://fast-cove-56939.herokuapp.com/payment",
            "cancel_url": "https://fast-cove-56939.herokuapp.com/payment"
        },
        "transactions": [{
            "item_list": {
                "items": [{
                    "name": "iService Subsription",
                    "price": "1.99",
                    "currency": "AUD",
                    "quantity": 1
                }]
            },
            "amount": {
                "currency": "AUD",
                "total": "1.99"
            },
            "description": "Subscribe with iService base subscription to recieve the essential necessities"
        }]
    }
    Paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            throw error;
        } else {
            for(let i = 0;i < payment.links.length;i++){
              if(payment.links[i].rel === 'approval_url'){
                res.redirect(payment.links[i].href);
              }
            }
        }
    })
})

app.post('/', (req, res)=> {            //Retrieves the post from the login page
    const email = req.body.email
    const password = req.body.password

    User.findOne({email: email}, (err, user) =>{
        if (err)
        {res.send("Please enter a valid email")}
        else{
            bcrypt.compare(password, user.password, (err, result) =>{
                if (result){
                    res.send("Successfully Logged In")
                }
                else
                {res.send("Invalid email or Password")}
            })
        }
    })

    passport.authenticate('local', { failureRedirect: '/login', failureFlash: true }),
    function(req, res, next) {
        if (!req.body.remember_me) { return next(); 
    }

    var token = utils.generateToken(64);
    RememberMeStrategy.save(token, { userId: req.user.id }, function(err) {
      if (err) { return done(err); }
      res.cookie('remember_me', token, { path: '/', httpOnly: true, maxAge: 604800000 }); // 7 days
      return next();
    })}
})

app.post('/signup', (req, res)=> {            //Retrieves the post from the signup page
    
    const salt = bcrypt.genSaltSync(saltRounds)
    

    const first = req.body.first
    const last = req.body.last
    const email = req.body.email
    const residence = req.body.residence
    const password = bcrypt.hashSync(req.body.password, salt)
    const conpassword = bcrypt.hashSync(req.body.conpassword, salt)
    const address = req.body.address
    const city = req.body.city
    const state = req.body.state
    const postal = req.body.postal
    const mobile = req.body.mobile

    if(!validator.equals(password, conpassword)) {
        res.status(400).send("Passwords do not match")
    }
    else {  

        const NewUser = new User(
        {
            first: first,
            last: last,
            email: email,
            residence: residence,
            password: password,
            conpassword: conpassword,
            address: address,
            city: city,
            state: state,
            postal: postal,
            mobile: mobile
        }
    )
        NewUser.save((err)=>{           //Prints the data into the selected database
            if(err)
            {console.log(err)}
            else
            {console.log("Inserted Successfully")}
        })
    }
    
    res.redirect('/')
    
})

//Listen Request
//
//
//

let port = process.env.PORT;
if (port == null || port == "") {
    port = 8080;
}
app.listen(port); 

// app.listen(3000, function (request, response) {
//     console.log("Server is running on port 3000")
// })