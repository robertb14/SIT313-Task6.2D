
//Robert Bajan 10/10/21
module.exports={
    clientId: "614490059969-tppk604olch6n759c6tico67dr0kp08h.apps.googleusercontent.com",
    secret: "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",
    callback: "https://fast-cove-56939.herokuapp.com/google/callback",
    PublishableKey: "pk_test_51JmD2DIKf5zS3vuDGd6Ugl5lJUXxYuxxp26Cj6yiJ9JNIpoxoPl9Zjoa0GyqSdMkNNOgsSqW3a7Vap68iMJvQQNO00kVpKBntT",
    SecretKey: "sk_test_51JmD2DIKf5zS3vuDhjqfs5ViYBV0tIRAjY1CaCQ8ryiQnt77jKumv4G0b6rt5iyqte420VXKsot16Ys9DFqcMFTU00TNDVUYDb",
    mode: "sandbox",
    paypalClientId: "AXUC3SfxNti_mOtO05aq8y0RI5VQpI9qRv8N-iII1dZrTeJ1TA2uthRgb3QGHt8oSQvh1zPpPEi-19Xa",
    paypalSecret: "ECvU-S4-GnrPy96RNMMusHWUTFbvh0DOVK-dACG-GgyaQlB5lXF8iKtz071vu_nFz5-ZC2vdERkyU9jW"
}